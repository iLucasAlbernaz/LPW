package beans;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class UserDAO {
    public static boolean login(String user, String password){
        Connection con = null;
        PreparedStatement ps = null;
        try{
            con = Database.getConnection();
            ps = con.clientPrepareStatement( 
                    "select user, pass from userinfo where user = ? and pass= ?");
            ps.setString(1, user);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                System.out.println(rs.getString("user"));
                return true;
            }
            else {
                return false;
        }
        }catch (Exception ex){
            System.out.println("Erro no login() -->" + ex.getMessage());
            return false;
        }finally{
            Database.close(con);
        }
    }
}
