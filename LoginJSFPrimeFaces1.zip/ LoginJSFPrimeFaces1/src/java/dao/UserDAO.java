package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {
    public static boolean login(String user, String password) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = Database.getConnection();
            System.out.println("Conexão com o banco estabelecida.");

            String sql = "SELECT `user`, pass FROM userinfo WHERE `user` = ? AND pass = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, user);
            ps.setString(2, password);

            System.out.println("Executando consulta SQL: " + sql);
            System.out.println("Usuário: " + user);
            System.out.println("Senha: " + password);

            rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Usuário encontrado: " + rs.getString("user"));
                return true;
            } else {
                System.out.println("Usuário não encontrado ou senha incorreta.");
                return false;
            }
        } catch (Exception ex) {
            System.out.println("Erro no login() --> " + ex.getMessage());
            return false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception ex) {
                System.out.println("Erro ao fechar recursos --> " + ex.getMessage());
            }
        }
    }
}
