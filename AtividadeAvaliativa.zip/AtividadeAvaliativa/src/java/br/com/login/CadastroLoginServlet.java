package br.com.login;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CadastroLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public CadastroLoginServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter writer = response.getWriter();
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String senha = request.getParameter("senha");

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            con = CriarConexao.getConexao();

            // Verifica se o email já existe no banco
            String sqlCheckEmail = "SELECT * FROM tb_login WHERE email = ?";
            stmt = con.prepareStatement(sqlCheckEmail);
            stmt.setString(1, email);
            rs = stmt.executeQuery();

            if (rs.next()) {
                // Se o e-mail já existe, redireciona para uma página de erro
                request.setAttribute("erro", "Este e-mail ja foi cadastrado. Favor, insirir outro e-mail!");
                request.getRequestDispatcher("erroCadastro.jsp").forward(request, response);
            } else {
                // Caso contrário, continua o cadastro
                Usuario u = new Usuario();
                u.setNome(nome);
                u.setEmail(email);
                u.setSenha(senha);

                UsuarioDAO dao = new UsuarioDAO(con);
                dao.adicionar(u);
                request.setAttribute("nome", u.getNome());
                request.setAttribute("email", u.getEmail());
                request.getRequestDispatcher("cadastrado.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
