package controller;

import dao.ClienteDAO;
import java.io.Serializable;
import java.util.List;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import model.Cliente;

@Named
@ViewScoped
public class ClienteBean implements Serializable {

    private ClienteDAO clienteDAO;
    private Cliente cliente = new Cliente();
    private DataModel<Cliente> clientes;

    // Construtor para inicializar o clienteDAO
    public ClienteBean() {
        clienteDAO = new ClienteDAO();
    }

    // Método para criar um novo cliente
    public void novo() {
        cliente = new Cliente(); // Cria um novo objeto cliente
    }

    // Método para inserir um novo cliente
    public String inserir() {
        String resultado = "falha";  // Resultado padrão em caso de erro
        boolean retorno = clienteDAO.inserir(cliente);  // Tenta inserir o cliente no banco de dados

        if (retorno) {
            resultado = "clientes";  // Redireciona para a página de clientes caso o retorno seja positivo
        }

        return resultado;
    }

    // Método para selecionar um cliente da lista
    public void selecionar() {
        cliente = clientes.getRowData();  // Obtém o cliente selecionado da tabela
    }

    // Método para alterar um cliente
    public String alterar() {
        String resultado = "falha";
        boolean retorno = clienteDAO.alterar(cliente);  // Tenta alterar o cliente no banco de dados

        if (retorno) {
            resultado = "cliente";  // Redireciona para a página de cliente alterado
        }

        return resultado;
    }

    // Método para remover um cliente
    public String remover() {
        String resultado = "falha";
        boolean retorno = clienteDAO.remover(cliente);  // Tenta remover o cliente do banco de dados

        if (retorno) {
            resultado = "clientes";  // Redireciona para a lista de clientes
        }

        return resultado;
    }

    // Métodos de acesso para o cliente
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    // Método para listar os clientes
    public DataModel<Cliente> getClientes() {
        List<Cliente> clienteList = clienteDAO.listar();  // Recupera a lista de clientes do banco
        clientes = new ListDataModel<>(clienteList);  // Converte a lista para DataModel
        return clientes;
    }

    // Método para setar os clientes (não é necessário, pois o getClientes já faz isso)
    public void setClientes(DataModel<Cliente> clientes) {
        this.clientes = clientes;
    }
}
