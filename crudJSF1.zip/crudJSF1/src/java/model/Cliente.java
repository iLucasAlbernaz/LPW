package model;

import java.util.Objects;

public class Cliente {
    
    private int codigo;
    private String nome;
    private String telefone;

    // Getter e Setter para 'codigo'
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    // Getter e Setter para 'nome' com validação simples
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome != null && !nome.trim().isEmpty()) {
            this.nome = nome;
        } else {
            throw new IllegalArgumentException("Nome não pode ser vazio.");
        }
    }

    // Getter e Setter para 'telefone' com validação simples
    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        if (telefone != null && telefone.matches("\\d{10,11}")) {
            this.telefone = telefone;
        } else {
            throw new IllegalArgumentException("Telefone inválido. Deve ter 10 ou 11 dígitos.");
        }
    }

    // Método toString() para facilitar a visualização do objeto Cliente
    @Override
    public String toString() {
        return "Cliente{codigo=" + codigo + ", nome='" + nome + "', telefone='" + telefone + "'}";
    }

    // Método equals() e hashCode() para comparar e gerenciar objetos Cliente em coleções
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Cliente cliente = (Cliente) obj;
        return codigo == cliente.codigo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
