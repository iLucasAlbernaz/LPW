package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Cliente;

public class ClienteDAO {
    
    private Conexao conexao;
    
    public ClienteDAO() {
        conexao = new Conexao();
    }

    // Método auxiliar para obter a conexão
    private Connection getConnection() throws SQLException {
        return conexao.getConn();
    }

    // Método auxiliar para fechar os recursos
    private void fecharRecursos(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Logar erro ao fechar recursos
        }
    }
    
    public boolean inserir(Cliente cliente) {
        String sql = "INSERT INTO cliente (nome, telefone) VALUES (?, ?)";
        try (Connection conn = getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getTelefone());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace(); // Logar erro para debugging
        }
        return false;
    }
    
    public boolean alterar(Cliente cliente) {
        String sql = "UPDATE cliente SET nome = ?, telefone = ? WHERE codigo = ?";
        try (Connection conn = getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getTelefone());
            stmt.setInt(3, cliente.getCodigo());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace(); // Logar erro para debugging
        }
        return false;
    }
    
    public boolean remover(Cliente cliente) {
        String sql = "DELETE FROM cliente WHERE codigo = ?";
        try (Connection conn = getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, cliente.getCodigo());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace(); // Logar erro para debugging
        }
        return false;
    }
    
    public List<Cliente> listar() {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM cliente ORDER BY nome";
        
        try (Connection conn = getConnection(); 
             Statement stmt = conn.createStatement(); 
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setCodigo(rs.getInt("codigo"));
                cliente.setNome(rs.getString("nome"));
                cliente.setTelefone(rs.getString("telefone"));
                
                clientes.add(cliente);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Logar erro para debugging
        }
        
        return clientes;
    }
}
