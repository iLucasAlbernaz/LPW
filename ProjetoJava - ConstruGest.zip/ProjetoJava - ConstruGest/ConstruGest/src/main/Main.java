    package main;

    import construgest.Cliente;
    import construgest.Projeto;
    import dao.ClienteDAO;
    import dao.ProjetoDAO;

    import javax.swing.*;
    import java.text.ParseException;
    import java.text.SimpleDateFormat;
    import java.util.Date;
    import java.util.List;

    public class Main {

        private static final ClienteDAO clienteDAO = new ClienteDAO();
        private static final ProjetoDAO projetoDAO = new ProjetoDAO();

        public static void main(String[] args) {
            while (true) {
                String escolha = exibirMenu();

                switch (escolha) {
                    case "1":
                        cadastrarCliente();
                        break;
                    case "2":
                        cadastrarProjeto();
                        break;
                    case "3":
                        listarProjetos();
                        break;
                    case "4":
                        listarProjetosCliente();
                        break;
                    case "5":
                        atualizarProjeto();
                        break;
                    case "6":
                        excluirCliente();
                        break;
                    case "7":
                        JOptionPane.showMessageDialog(null, "Saindo do programa...");
                        return;
                    default:
                        JOptionPane.showMessageDialog(null, "Opção inválida!");
                }
            }
        }

        private static String exibirMenu() {
            return (String) JOptionPane.showInputDialog(
                    null,
                    "Escolha uma opção:\n" +
                            "1 - Cadastrar Cliente\n" +
                            "2 - Cadastrar Projeto\n" +
                            "3 - Listar Projetos\n" +
                            "4 - Listar Projetos do Cliente\n" +
                            "5 - Atualizar Projeto\n" +
                            "6 - Excluir Cliente\n" +
                            "7 - Sair",
                    "Menu Principal",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    null,
                    "1");
        }

        private static void cadastrarCliente() {
            Cliente cliente = criarCliente();
            if (cliente != null) {
                clienteDAO.adicionarCliente(cliente);
                JOptionPane.showMessageDialog(null, "Cliente cadastrado com sucesso!");
            }
        }

        private static Cliente criarCliente() {
            Cliente cliente = new Cliente();
            cliente.setNome(JOptionPane.showInputDialog("Digite o nome do cliente:"));
            cliente.setEndereco(JOptionPane.showInputDialog("Digite o endereço do cliente:"));
            cliente.setTelefone(JOptionPane.showInputDialog("Digite o telefone do cliente:"));
            cliente.setEmail(JOptionPane.showInputDialog("Digite o email do cliente:"));
            return cliente;
        }

        private static void cadastrarProjeto() {
            Cliente cliente = selecionarCliente();
            if (cliente != null) {
                Projeto projeto = criarProjeto();
                projeto.setCliente(cliente);

                projetoDAO.adicionarProjeto(projeto);
                JOptionPane.showMessageDialog(null, "Projeto cadastrado com sucesso!");
            }
        }

        private static Projeto criarProjeto() {
            Projeto projeto = new Projeto();
            projeto.setNome(JOptionPane.showInputDialog("Digite o nome do projeto:"));
            projeto.setDescricao(JOptionPane.showInputDialog("Digite a descrição do projeto:"));

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            try {
                Date dataInicio = dateFormat.parse(JOptionPane.showInputDialog("Digite a data de início do projeto (formato dd/MM/yyyy):"));
                Date dataFim = dateFormat.parse(JOptionPane.showInputDialog("Digite a data de fim do projeto (formato dd/MM/yyyy):"));
                projeto.setDataInicio(dataInicio);
                projeto.setDataFim(dataFim);
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(null, "Erro ao converter data. O projeto será cadastrado com datas atuais.");
                projeto.setDataInicio(new Date());
                projeto.setDataFim(new Date());
            }

            try {
                projeto.setValor(Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do projeto:")));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Valor inválido. O projeto será cadastrado sem valor.");
                projeto.setValor(0.0);
            }

            return projeto;
        }

        private static void listarProjetos() {
            List<Projeto> projetos = projetoDAO.listarProjetos();
            exibirListaProjetos(projetos);
        }

        private static void listarProjetosCliente() {
            Cliente cliente = selecionarCliente();
            if (cliente != null) {
                List<Projeto> projetosCliente = clienteDAO.listarProjetosDoCliente(cliente);
                exibirListaProjetos(projetosCliente);
            }
        }

        private static void exibirListaProjetos(List<Projeto> projetos) {
            StringBuilder projetosStr = new StringBuilder("Lista de Projetos:\n");
            for (Projeto p : projetos) {
                projetosStr.append(p.getId()).append(": ").append(p.getNome()).append(" (Cliente: ").append(p.getCliente().getNome()).append(")\n");
            }
            JOptionPane.showMessageDialog(null, projetosStr.toString());
        }

        private static void atualizarProjeto() {
            Cliente cliente = selecionarCliente();
            if (cliente != null) {
                List<Projeto> projetosCliente = clienteDAO.listarProjetosDoCliente(cliente);
                if (!projetosCliente.isEmpty()) {
                    Projeto projetoParaAtualizar = selecionarProjeto(projetosCliente);
                    if (projetoParaAtualizar != null) {
                        projetoParaAtualizar.setNome(JOptionPane.showInputDialog("Digite o novo nome do projeto:"));
                        projetoDAO.atualizarProjeto(projetoParaAtualizar);
                        JOptionPane.showMessageDialog(null, "Projeto atualizado com sucesso!");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "O cliente selecionado não possui projetos cadastrados.");
                }
            }
        }

        private static Projeto selecionarProjeto(List<Projeto> projetos) {
            String[] nomesProjetos = projetos.stream().map(Projeto::getNome).toArray(String[]::new);
            String nomeProjeto = (String) JOptionPane.showInputDialog(
                    null,
                    "Selecione um projeto:",
                    "Seleção de Projeto",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    nomesProjetos,
                    nomesProjetos[0]);

            if (nomeProjeto != null) {
                for (Projeto projeto : projetos) {
                    if (projeto.getNome().equals(nomeProjeto)) {
                        return projeto;
                    }
                }
            }
            return null;
        }

       private static void excluirCliente() {
    Cliente cliente = selecionarCliente();
    if (cliente != null) {
        List<Projeto> projetosCliente = clienteDAO.listarProjetosDoCliente(cliente);
        
        // Confirmar a exclusão
        int confirmacao = JOptionPane.showConfirmDialog(
                null,
                "Tem certeza que deseja excluir o cliente " + cliente.getNome() + " e todos os seus projetos associados?",
                "Confirmar Exclusão",
                JOptionPane.YES_NO_OPTION);
        
        if (confirmacao == JOptionPane.YES_OPTION) {
            // Excluir projetos associados ao cliente
            for (Projeto projeto : projetosCliente) {
                projetoDAO.excluirProjeto(projeto.getId());
            }
            
            // Excluir o cliente após excluir os projetos
            clienteDAO.excluirCliente(cliente.getId());
            JOptionPane.showMessageDialog(null, "Cliente e projetos associados excluídos com sucesso!");
        } else {
            JOptionPane.showMessageDialog(null, "Exclusão cancelada.");
        }
    }
}
        private static Cliente selecionarCliente() {
            List<Cliente> clientes = clienteDAO.listarClientes();
            if (clientes.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Não há clientes cadastrados.");
                return null;
            }

            String[] nomesClientes = clientes.stream().map(Cliente::getNome).toArray(String[]::new);
            String nomeCliente = (String) JOptionPane.showInputDialog(
                    null,
                    "Selecione um cliente:",
                    "Seleção de Cliente",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    nomesClientes,
                    nomesClientes[0]);

            if (nomeCliente != null) {
                for (Cliente cliente : clientes) {
                    if (cliente.getNome().equals(nomeCliente)) {
                        return cliente;
                    }
                }
            }
            return null;
        }
    }
