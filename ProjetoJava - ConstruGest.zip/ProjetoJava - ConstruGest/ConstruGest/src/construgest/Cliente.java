package construgest;

import java.util.ArrayList;
import java.util.List;

public class Cliente extends Entidade {
    private String nome;
    private String endereco;
    private String telefone;
    private String email;
    private List<Projeto> projetos;

    public Cliente() {
        this.projetos = new ArrayList<>();
    }

    // Getters e Setters

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Projeto> getProjetos() {
        return projetos;
    }

    public void setProjetos(List<Projeto> projetos) {
        this.projetos = projetos;
    }

    // Métodos adicionais

    public void adicionarProjeto(Projeto projeto) {
        this.projetos.add(projeto);
    }

    @Override
    public String getDescricao() {
        return "Cliente: " + nome;
    }
}
