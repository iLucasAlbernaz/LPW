package dao;

import construgest.Cliente;
import construgest.Projeto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProjetoDAO {

    public void adicionarProjeto(Projeto projeto) {
        String sql = "INSERT INTO Projeto (nome, descricao, data_inicio, data_fim, cliente_id, valor) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, projeto.getNome());
            stmt.setString(2, projeto.getDescricao());
            stmt.setDate(3, new java.sql.Date(projeto.getDataInicio().getTime()));
            stmt.setDate(4, new java.sql.Date(projeto.getDataFim().getTime()));
            stmt.setInt(5, projeto.getCliente().getId());
            stmt.setDouble(6, projeto.getValor());
            stmt.executeUpdate();

            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                projeto.setId(generatedKeys.getInt(1));
            } else {
                throw new SQLException("Falha ao obter o ID gerado para o projeto.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Projeto> listarProjetos() {
        String sql = "SELECT p.*, c.id as cliente_id, c.nome as cliente_nome, c.endereco as cliente_endereco, c.telefone as cliente_telefone, c.email as cliente_email " +
                     "FROM Projeto p " +
                     "INNER JOIN Cliente c ON p.cliente_id = c.id";
        List<Projeto> projetos = new ArrayList<>();

        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Projeto projeto = new Projeto();
                projeto.setId(rs.getInt("id"));
                projeto.setNome(rs.getString("nome"));
                projeto.setDescricao(rs.getString("descricao"));
                projeto.setDataInicio(rs.getDate("data_inicio"));
                projeto.setDataFim(rs.getDate("data_fim"));
                projeto.setValor(rs.getDouble("valor"));

                // Cliente associado ao projeto
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("cliente_id"));
                cliente.setNome(rs.getString("cliente_nome"));
                cliente.setEndereco(rs.getString("cliente_endereco"));
                cliente.setTelefone(rs.getString("cliente_telefone"));
                cliente.setEmail(rs.getString("cliente_email"));

                projeto.setCliente(cliente);

                projetos.add(projeto);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return projetos;
    }

    public void atualizarProjeto(Projeto projeto) {
        String sql = "UPDATE Projeto SET nome = ?, descricao = ?, data_inicio = ?, data_fim = ?, cliente_id = ?, valor = ? WHERE id = ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, projeto.getNome());
            stmt.setString(2, projeto.getDescricao());
            stmt.setDate(3, new java.sql.Date(projeto.getDataInicio().getTime()));
            stmt.setDate(4, new java.sql.Date(projeto.getDataFim().getTime()));
            stmt.setInt(5, projeto.getCliente().getId());
            stmt.setDouble(6, projeto.getValor());
            stmt.setInt(7, projeto.getId());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluirProjeto(int id) {
        String sql = "DELETE FROM Projeto WHERE id = ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
