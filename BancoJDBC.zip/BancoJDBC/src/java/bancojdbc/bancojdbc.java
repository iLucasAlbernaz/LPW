package bancojdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
        
public class bancojdbc {
    private Connection con;
    private Statement stmt;
    
    public bancojdbc(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver encontrado!");
            } catch(ClassNotFoundException e){
            System.out.println("Driver não encontrado!" + e);
            System.out.println("Error: "+ e.getMessage());
        }
        
        String url = "jdbc:mysql://localhost:8080/Banco";
            String user = "root";
            String password = "";
        try{
        
        con=DriverManager.getConnection(url,user,password);
        stmt = con.createStatement();
        } catch (SQLException e){
            System.out.println("Error: "+ e.getMessage());      
        }
    inserirRegitro();     
}
    private void inserirRegitro() {
       try{
       stmt.executeUpdate("INSERT INTO Empregado VALUES (4,'Evandro','6291376654','6780.00')");
       }catch (SQLException e){
           System.out.println("Error: "+ e.getMessage());
       }
    public static void main (String[] args) {
        BancoJDBC bancojdbc = new BancoJDBC(); 
    }
    }
}

